#!/bin/bash
cppython npspeedtest.py
